package com.example.practica20

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.annotation.RequiresApi
import androidx.core.view.ViewCompat.jumpDrawablesToCurrentState
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import java.util.*

private const val TAG="CrimeFragment"
private const val ARG_CRIME_ID="crime_id"
private const val REQUEST_CONTACT=1
private const val DATE_FORMAT = "EEE, MMM, dd"
class CrimeFragment : Fragment(),DatePickerFragment.Callbacks, TimePickerFragment.Callbacks, CrimeListFragment.Callbacks {
    private lateinit var crime: Crime
    private lateinit var titleField: EditText
    private lateinit var solvedCheckBox: CheckBox
    private lateinit var reportButton: Button
    private lateinit var suspectButton: Button
    private lateinit var perehod: Button
    private lateinit var addBd: Button
    private lateinit var dateButton: Button

    private val crimeDetailViewModel:CrimeDatailModel by lazy{
        ViewModelProviders.of(this).get(CrimeDatailModel::class.java)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        crime=Crime()
        val crimeId: UUID? = arguments?.getSerializable(ARG_CRIME_ID) as? UUID

        Log.d(TAG, "args bundle crime ID: $crimeId")

    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_crime,container,false)
        titleField = view.findViewById(R.id.crime_title) as EditText
        dateButton = view.findViewById(R.id.crime_date) as Button
        solvedCheckBox = view.findViewById(R.id.crime_solved) as CheckBox
        reportButton=view.findViewById(R.id.crime_report) as Button
        suspectButton=view.findViewById(R.id.crime_suspect) as Button
        perehod = view.findViewById(R.id.perehodList) as Button
        addBd = view.findViewById(R.id.addBaza) as Button
        dateButton.apply { text = crime.date.toString(); isEnabled = false }
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?){
        super.onViewCreated(view, savedInstanceState)
        crimeDetailViewModel.crimeLiveData.observe(
            viewLifecycleOwner,
            androidx.lifecycle.Observer {
                    crime -> crime?.let {
                this.crime=crime
                updateUI()
            }
            }
        )
    }

    override fun onStart() {
        super.onStart()

        val titleWatcher = object : TextWatcher
        {
            override fun beforeTextChanged(sequence: CharSequence?,start: Int,count: Int,after: Int) {


            }


            override fun onTextChanged(sequence: CharSequence?,start: Int,before: Int,count: Int) {
                crime.title = sequence.toString()
            }

            override fun afterTextChanged(sequence: Editable?) {

            }
        }
        //сохранение в бд
        addBd.setOnClickListener(){
            var crime = Crime()
            crime.title = titleField.text.toString()
            crime.date = Date()
            crime.isSolved = solvedCheckBox.isChecked
            crimeDetailViewModel.addcrime(crime)
        }
        //доступность кнопок
        solvedCheckBox.setOnClickListener(){
            suspectButton.isEnabled = solvedCheckBox.isChecked
            reportButton.isEnabled = solvedCheckBox.isChecked
        }
        //просмотр листа
        perehod.setOnClickListener(){
// Создаем новый экземпляр вашего фрагмента CrimeListFragment
            val crimeListFragment = CrimeListFragment()

            // Получаем объект FragmentManager
            val fragmentManager = requireFragmentManager()

            // Начинаем транзакцию фрагментов
            val transaction = fragmentManager.beginTransaction()

            // Заменяем текущий фрагмент на CrimeListFragment
            transaction.replace(R.id.fragment_container, crimeListFragment)

            // Добавляем транзакцию в стек возврата, чтобы пользователь мог вернуться к предыдущему фрагменту
            transaction.addToBackStack(null)

            // Применяем транзакцию
            transaction.commit()
        }

        titleField.addTextChangedListener(titleWatcher)
        solvedCheckBox.apply{
            setOnCheckedChangeListener{_,isChecked ->
                crime.isSolved = isChecked
            }

        }

        reportButton.setOnClickListener {
            Intent(Intent.ACTION_SEND).apply{
                type="text/plain"
                putExtra(Intent.EXTRA_TEXT,getCrimeReport())
                putExtra(Intent.EXTRA_SUBJECT,getString(R.string.crime_report_subject))
            }.also{
                    intent ->
                val chooserIntent=Intent.createChooser(intent,getString(R.string.send_report))
                startActivity(chooserIntent)
            }

        }
        suspectButton.apply{
            val pickContactIntent=Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
            setOnClickListener {
                startActivityForResult(pickContactIntent, REQUEST_CONTACT)
            }
            //pickContactIntent.addCategory(Intent.CATEGORY_HOME)
            val packageManager: PackageManager =requireActivity().packageManager
            val resolvedActivity: ResolveInfo?=packageManager.resolveActivity(pickContactIntent, PackageManager.MATCH_DEFAULT_ONLY)
            if (resolvedActivity==null){
                isEnabled=false
            }
        }


    }

    override fun onStop(){
        super.onStop()
        crimeDetailViewModel.saveCrime(crime)
    }

    override fun onDateSelected(date: Date?) {
        crime.date=date
        updateUI()
    }

    override fun onTimeSelected(time: Date) {
        crime.date=time
        updateUI()
    }
    private fun updateUI(){
        titleField.setText(crime.title)
        solvedCheckBox.apply {
            isChecked=crime.isSolved!!
            jumpDrawablesToCurrentState()
        }
        if (crime.suspect.isNotEmpty()){
            suspectButton.text=crime.suspect
        }
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when{
            resultCode!= Activity.RESULT_OK -> return
            requestCode== REQUEST_CONTACT && data !=null ->{
                val contactUri: Uri? =data.data
                val queryFields=arrayOf(ContactsContract.Contacts.DISPLAY_NAME)
                val cursor =
                    contactUri?.let {
                        requireActivity().contentResolver.query(it,queryFields,null,
                            null)
                    }
                cursor?.use {
                    if (it.count==0){
                        return
                    }
                    it.moveToFirst()
                    val suspect=it.getString(0)
                    crime.suspect=suspect
                    crimeDetailViewModel.saveCrime(crime)
                    suspectButton.text=suspect
                }

            }
        }
        //updateUI()
    }
    private fun getCrimeReport(): String{//7 задание
        val solvedString = if (crime.isSolved == true){
            getString(R.string.crime_report_solved)
        }
        else{
            getString(R.string.crime_report_unsolved)
        }
        val dateString= DateFormat.format(DATE_FORMAT,crime.date).toString()
        var suspect=if (crime.suspect.isBlank()){
            getString(R.string.crime_report_no_suspect)
        }
        else{
            getString(R.string.crime_report_suspect, crime.suspect)
        }
        return getString(R.string.crime_report,crime.title,dateString,solvedString,suspect)
    }
    companion object{
        fun newInstance(crimeId:UUID):CrimeFragment{
            val args=Bundle().apply { putSerializable(ARG_CRIME_ID, crimeId) }
            return CrimeFragment().apply {
                arguments=args
            }
        }
    }

    override fun onCrimeSelected(crimeId: UUID) {
        TODO("Not yet implemented")
    }
}